AngularBestPracticesFiles
=========================

A few files from my Angular Best Practices course on Pluralsight.com

To run the node server, type "node web-server.js" from the directory that contains the web-server.js file
